using ProjetoSOLID.controller;
using ProjetoSOLID.dados;
using ProjetoSOLID.model;
using ProjetoSOLID.view;

namespace ProjetoSOLID;

internal class Program
{
    private static void Main()
    {
        try
        {
            var conexao = new SqlConnectionFactory();
            DatabaseInitializer.CriarBancoETabelas(conexao);

            IRepository<Produto> produtoRepository = new ProdutoRepository(conexao);
            IRepository<Compra> compraRepository = new CompraRepository(conexao);

            var produtoView = new ProdutoView();
            var compraView = new CompraView();
            var cadastroProdutoView = new CadastroProduto();
            var cadastroCompraView = new CadastroCompra(produtoRepository);

            var produtoController = new ProdutoController(produtoView, produtoRepository, cadastroProdutoView);
            var compraController = new CompraController(compraView, compraRepository, cadastroCompraView, produtoRepository);
            IMenuView menu = new MenuConsoleView();

            int opcao;
            do
            {
                opcao = menu.ExibirMenu();
                Console.Clear();
                switch (opcao)
                {
                    case 1: produtoController.Cadastrar(); break;
                    case 2: produtoController.Listar(); break;
                    case 3: produtoController.ExibirBusca(); break;
                    case 4: produtoController.Atualizar(); break;
                    case 5: produtoController.Remover(); break;
                    case 6: compraController.Cadastrar(); break;
                    case 7: compraController.Listar(); break;
                    case 8: compraController.ExibirBusca(); break;
                    case 9: compraController.Atualizar(); break;
                    case 10: compraController.Remover(); break;
                    case 0: Console.WriteLine("Encerrando o sistema..."); break;
                    default: Console.WriteLine("Opção inválida."); break;
                }

                if (opcao != 0)
                {
                    Console.WriteLine("\nPressione qualquer tecla para continuar...");
                    Console.ReadKey();
                }
            } while (opcao != 0);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Não foi possível iniciar o sistema.");
            Console.WriteLine($"Detalhes: {ex.Message}");
            Console.WriteLine("\nConfira se o SQL Server (localhost\\SQLEXPRESS) está iniciado e se o pacote NuGet foi restaurado.");
            Console.ReadKey();
        }
    }
}
