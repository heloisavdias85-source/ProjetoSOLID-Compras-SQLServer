using ProjetoSOLID.dados;
using ProjetoSOLID.model;
using ProjetoSOLID.view;

namespace ProjetoSOLID.controller;

public class ProdutoController
{
    private readonly IProdutoView _view;
    private readonly IRepository<Produto> _repository;
    private readonly ICadastroView<Produto> _cadastroView;

    public ProdutoController(IProdutoView view, IRepository<Produto> repository, ICadastroView<Produto> cadastroView)
    { _view = view; _repository = repository; _cadastroView = cadastroView; }

    public void Cadastrar() => Executar(() => { _repository.Adicionar(_cadastroView.ObterDados()); _cadastroView.ExibirMensagem("Produto cadastrado com sucesso!"); });
    public void Listar() => _view.MostrarProdutos(_repository.ListarTodos());

    public void ExibirBusca()
    {
        int id = LerId("Informe o ID do produto: ");
        var produto = _repository.BuscarPorId(id);
        if (produto is null) Console.WriteLine("Produto não encontrado."); else _view.MostrarProduto(produto);
    }

    public void Atualizar()
    {
        int id = LerId("ID do produto que deseja atualizar: ");
        if (_repository.BuscarPorId(id) is null) { Console.WriteLine("Produto não encontrado."); return; }
        var novo = _cadastroView.ObterDados(); novo.Id = id;
        Executar(() => { _repository.Atualizar(novo); Console.WriteLine("Produto atualizado!"); });
    }

    public void Remover()
    {
        int id = LerId("ID do produto que deseja excluir: ");
        Executar(() => { _repository.Remover(id); Console.WriteLine("Produto excluído!"); });
    }

    private static int LerId(string texto) { Console.Write(texto); return int.TryParse(Console.ReadLine(), out int id) ? id : -1; }
    private static void Executar(Action acao) { try { acao(); } catch (Exception ex) { Console.WriteLine($"Não foi possível concluir: {ex.Message}"); } }
}
