using ProjetoSOLID.dados;
using ProjetoSOLID.model;
using ProjetoSOLID.view;

namespace ProjetoSOLID.controller;

public class CompraController
{
    private readonly ICompraView _view;
    private readonly IRepository<Compra> _repository;
    private readonly ICadastroView<Compra> _cadastroView;

    public CompraController(ICompraView view, IRepository<Compra> repository,
        ICadastroView<Compra> cadastroView, IRepository<Produto> produtoRepository)
    { _view = view; _repository = repository; _cadastroView = cadastroView; }

    public void Cadastrar() => Executar(() => { _repository.Adicionar(_cadastroView.ObterDados()); Console.WriteLine("Compra cadastrada com sucesso!"); });
    public void Listar() => _view.MostrarCompras(_repository.ListarTodos());

    public void ExibirBusca()
    {
        int id = LerId("Informe o ID da compra: ");
        var compra = _repository.BuscarPorId(id);
        if (compra is null) Console.WriteLine("Compra não encontrada."); else _view.MostrarCompra(compra);
    }

    public void Atualizar()
    {
        int id = LerId("ID da compra que deseja atualizar: ");
        if (_repository.BuscarPorId(id) is null) { Console.WriteLine("Compra não encontrada."); return; }
        Console.WriteLine("Informe novamente os produtos e quantidades da compra.");
        var atualizada = _cadastroView.ObterDados(); atualizada.Id = id;
        Executar(() => { _repository.Atualizar(atualizada); Console.WriteLine("Compra atualizada!"); });
    }

    public void Remover()
    {
        int id = LerId("ID da compra que deseja excluir: ");
        Executar(() => { _repository.Remover(id); Console.WriteLine("Compra excluída!"); });
    }

    private static int LerId(string texto) { Console.Write(texto); return int.TryParse(Console.ReadLine(), out int id) ? id : -1; }
    private static void Executar(Action acao) { try { acao(); } catch (Exception ex) { Console.WriteLine($"Não foi possível concluir: {ex.Message}"); } }
}
