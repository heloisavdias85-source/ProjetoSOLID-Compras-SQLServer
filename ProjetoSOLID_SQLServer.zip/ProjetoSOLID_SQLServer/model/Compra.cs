namespace ProjetoSOLID.model;

public class Compra
{
    public int Id { get; set; }
    public DateTime Data { get; set; }
    public List<ItemCompra> Itens { get; set; } = new();
    public decimal Total => Itens.Sum(item => item.Quantidade * item.PrecoUnitario);
}
