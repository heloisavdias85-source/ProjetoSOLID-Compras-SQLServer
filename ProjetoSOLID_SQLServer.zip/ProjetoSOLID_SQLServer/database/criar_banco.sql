IF DB_ID(N'ProjetoSOLID') IS NULL
    CREATE DATABASE ProjetoSOLID;
GO
USE ProjetoSOLID;
GO
IF OBJECT_ID(N'dbo.Produto', N'U') IS NULL
CREATE TABLE dbo.Produto (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nome NVARCHAR(120) NOT NULL,
    Preco DECIMAL(10,2) NOT NULL CHECK (Preco >= 0),
    Descricao NVARCHAR(500) NOT NULL
);
GO
IF OBJECT_ID(N'dbo.Compra', N'U') IS NULL
CREATE TABLE dbo.Compra (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Data DATETIME2 NOT NULL
);
GO
IF OBJECT_ID(N'dbo.ItemCompra', N'U') IS NULL
CREATE TABLE dbo.ItemCompra (
    CompraId INT NOT NULL,
    ProdutoId INT NOT NULL,
    Quantidade INT NOT NULL CHECK (Quantidade > 0),
    PrecoUnitario DECIMAL(10,2) NOT NULL CHECK (PrecoUnitario >= 0),
    CONSTRAINT PK_ItemCompra PRIMARY KEY (CompraId, ProdutoId),
    CONSTRAINT FK_ItemCompra_Compra FOREIGN KEY (CompraId) REFERENCES dbo.Compra(Id) ON DELETE CASCADE,
    CONSTRAINT FK_ItemCompra_Produto FOREIGN KEY (ProdutoId) REFERENCES dbo.Produto(Id)
);
GO
