# ProjetoSOLID - Compras com SQL Server

Projeto console em C#/.NET 8 com arquitetura MVC, repositórios e relacionamento N:N entre Compra e Produto.

## Banco configurado
Instância: `localhost\SQLEXPRESS`  
Banco: `ProjetoSOLID`  
Autenticação: Windows (Integrated Security)

Na primeira execução, o programa tenta criar o banco e as tabelas automaticamente. O usuário do Windows precisa ter permissão para criar banco de dados na instância. Se não tiver, execute `database/criar_banco.sql` no SQL Server Management Studio (SSMS) com uma conta que tenha essa permissão.

## Dependência
O projeto usa `Microsoft.Data.SqlClient` (NuGet). Não usa SQLite. A dependência é necessária para o .NET conversar com o SQL Server.

## Como abrir
1. Extraia a pasta.
2. Abra `ProjetoSOLID.csproj` no Visual Studio.
3. Se solicitado, restaure os pacotes NuGet.
4. Compile com **Compilar > Recompilar Solução**.
5. Execute com F5.

Se o NuGet não restaurar, verifique a conexão com a internet e a origem `nuget.org` em Ferramentas > Opções > Gerenciador de Pacotes NuGet > Origens do Pacote.

## Tabelas
- `Produto`: cadastro dos produtos.
- `Compra`: cabeçalho da compra.
- `ItemCompra`: tabela associativa que implementa o N:N, guardando quantidade e preço unitário no momento da compra.

## Observação
O programa cria as tabelas automaticamente na inicialização. A conexão integrada usa a conta do Windows que executa o Visual Studio.
