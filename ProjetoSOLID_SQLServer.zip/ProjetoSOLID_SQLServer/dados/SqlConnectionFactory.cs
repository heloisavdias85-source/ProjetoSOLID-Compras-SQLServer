using Microsoft.Data.SqlClient;

namespace ProjetoSOLID.dados;

public sealed class SqlConnectionFactory
{
    // Instância informada: localhost\SQLEXPRESS
    private const string ConnectionString =
        "Server=localhost\\SQLEXPRESS;Database=ProjetoSOLID;Integrated Security=True;TrustServerCertificate=True;";

    public SqlConnection CriarConexao() => new SqlConnection(ConnectionString);
}
