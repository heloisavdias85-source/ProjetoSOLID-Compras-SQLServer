using Microsoft.Data.SqlClient;
using ProjetoSOLID.model;

namespace ProjetoSOLID.dados;

public class ProdutoRepository : IRepository<Produto>
{
    private readonly SqlConnectionFactory _factory;
    public ProdutoRepository(SqlConnectionFactory factory) => _factory = factory;

    public void Adicionar(Produto produto)
    {
        using var conexao = _factory.CriarConexao();
        conexao.Open();
        using var cmd = new SqlCommand(
            "INSERT INTO dbo.Produto (Nome, Preco, Descricao) VALUES (@Nome, @Preco, @Descricao); SELECT CAST(SCOPE_IDENTITY() AS INT);", conexao);
        cmd.Parameters.AddWithValue("@Nome", produto.Nome);
        cmd.Parameters.AddWithValue("@Preco", produto.Preco);
        cmd.Parameters.AddWithValue("@Descricao", produto.Descricao);
        produto.Id = (int)cmd.ExecuteScalar()!;
    }

    public List<Produto> ListarTodos()
    {
        var lista = new List<Produto>();
        using var conexao = _factory.CriarConexao();
        conexao.Open();
        using var cmd = new SqlCommand("SELECT Id, Nome, Preco, Descricao FROM dbo.Produto ORDER BY Id;", conexao);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
            lista.Add(new Produto(reader.GetInt32(0), reader.GetString(1), reader.GetDecimal(2), reader.GetString(3)));
        return lista;
    }

    public Produto? BuscarPorId(int id)
    {
        using var conexao = _factory.CriarConexao();
        conexao.Open();
        using var cmd = new SqlCommand("SELECT Id, Nome, Preco, Descricao FROM dbo.Produto WHERE Id = @Id;", conexao);
        cmd.Parameters.AddWithValue("@Id", id);
        using var reader = cmd.ExecuteReader();
        return reader.Read()
            ? new Produto(reader.GetInt32(0), reader.GetString(1), reader.GetDecimal(2), reader.GetString(3))
            : null;
    }

    public void Atualizar(Produto produto)
    {
        using var conexao = _factory.CriarConexao();
        conexao.Open();
        using var cmd = new SqlCommand("UPDATE dbo.Produto SET Nome=@Nome, Preco=@Preco, Descricao=@Descricao WHERE Id=@Id;", conexao);
        cmd.Parameters.AddWithValue("@Id", produto.Id);
        cmd.Parameters.AddWithValue("@Nome", produto.Nome);
        cmd.Parameters.AddWithValue("@Preco", produto.Preco);
        cmd.Parameters.AddWithValue("@Descricao", produto.Descricao);
        if (cmd.ExecuteNonQuery() == 0) throw new InvalidOperationException("Produto não encontrado.");
    }

    public void Remover(Produto produto) => Remover(produto.Id);

    public void Remover(int id)
    {
        using var conexao = _factory.CriarConexao();
        conexao.Open();
        using var cmd = new SqlCommand("DELETE FROM dbo.Produto WHERE Id=@Id;", conexao);
        cmd.Parameters.AddWithValue("@Id", id);
        try
        {
            if (cmd.ExecuteNonQuery() == 0) throw new InvalidOperationException("Produto não encontrado.");
        }
        catch (SqlException ex) when (ex.Number == 547)
        {
            throw new InvalidOperationException("Este produto está vinculado a uma compra e não pode ser excluído.");
        }
    }
}
