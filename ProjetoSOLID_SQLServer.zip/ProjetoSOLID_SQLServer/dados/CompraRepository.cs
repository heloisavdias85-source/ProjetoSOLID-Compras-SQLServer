using Microsoft.Data.SqlClient;
using ProjetoSOLID.model;

namespace ProjetoSOLID.dados;

public class CompraRepository : IRepository<Compra>
{
    private readonly SqlConnectionFactory _factory;
    public CompraRepository(SqlConnectionFactory factory) => _factory = factory;

    public void Adicionar(Compra compra)
    {
        Validar(compra);
        using var conexao = _factory.CriarConexao();
        conexao.Open();
        using var transacao = conexao.BeginTransaction();
        try
        {
            using var cmdCompra = new SqlCommand(
                "INSERT INTO dbo.Compra (Data) VALUES (@Data); SELECT CAST(SCOPE_IDENTITY() AS INT);", conexao, transacao);
            cmdCompra.Parameters.AddWithValue("@Data", compra.Data);
            compra.Id = (int)cmdCompra.ExecuteScalar()!;

            InserirItens(compra, conexao, transacao);
            transacao.Commit();
        }
        catch { transacao.Rollback(); throw; }
    }

    public List<Compra> ListarTodos()
    {
        var compras = new List<Compra>();
        using var conexao = _factory.CriarConexao();
        conexao.Open();
        using (var cmd = new SqlCommand("SELECT Id, Data FROM dbo.Compra ORDER BY Id;", conexao))
        using (var reader = cmd.ExecuteReader())
            while (reader.Read())
                compras.Add(new Compra { Id = reader.GetInt32(0), Data = reader.GetDateTime(1) });

        foreach (var compra in compras) compra.Itens = BuscarItens(compra.Id, conexao);
        return compras;
    }

    public Compra? BuscarPorId(int id)
    {
        using var conexao = _factory.CriarConexao();
        conexao.Open();
        Compra? compra = null;
        using (var cmd = new SqlCommand("SELECT Id, Data FROM dbo.Compra WHERE Id=@Id;", conexao))
        {
            cmd.Parameters.AddWithValue("@Id", id);
            using var reader = cmd.ExecuteReader();
            if (reader.Read()) compra = new Compra { Id = reader.GetInt32(0), Data = reader.GetDateTime(1) };
        }
        if (compra != null) compra.Itens = BuscarItens(compra.Id, conexao);
        return compra;
    }

    public void Atualizar(Compra compra)
    {
        Validar(compra);
        using var conexao = _factory.CriarConexao();
        conexao.Open();
        using var transacao = conexao.BeginTransaction();
        try
        {
            using (var cmd = new SqlCommand("UPDATE dbo.Compra SET Data=@Data WHERE Id=@Id;", conexao, transacao))
            {
                cmd.Parameters.AddWithValue("@Id", compra.Id);
                cmd.Parameters.AddWithValue("@Data", compra.Data);
                if (cmd.ExecuteNonQuery() == 0) throw new InvalidOperationException("Compra não encontrada.");
            }
            using (var cmdExcluir = new SqlCommand("DELETE FROM dbo.ItemCompra WHERE CompraId=@Id;", conexao, transacao))
            {
                cmdExcluir.Parameters.AddWithValue("@Id", compra.Id);
                cmdExcluir.ExecuteNonQuery();
            }
            InserirItens(compra, conexao, transacao);
            transacao.Commit();
        }
        catch { transacao.Rollback(); throw; }
    }

    public void Remover(Compra compra) => Remover(compra.Id);

    public void Remover(int id)
    {
        using var conexao = _factory.CriarConexao();
        conexao.Open();
        using var cmd = new SqlCommand("DELETE FROM dbo.Compra WHERE Id=@Id;", conexao);
        cmd.Parameters.AddWithValue("@Id", id);
        if (cmd.ExecuteNonQuery() == 0) throw new InvalidOperationException("Compra não encontrada.");
    }

    private static void Validar(Compra compra)
    {
        if (compra.Itens == null || compra.Itens.Count == 0)
            throw new InvalidOperationException("A compra precisa ter pelo menos um produto.");
        if (compra.Itens.Any(i => i.Quantidade <= 0 || i.PrecoUnitario < 0))
            throw new InvalidOperationException("Quantidade e preço dos itens devem ser válidos.");
    }

    private static void InserirItens(Compra compra, SqlConnection conexao, SqlTransaction transacao)
    {
        foreach (var item in compra.Itens)
        {
            using var cmd = new SqlCommand(
                "INSERT INTO dbo.ItemCompra (CompraId, ProdutoId, Quantidade, PrecoUnitario) VALUES (@CompraId, @ProdutoId, @Quantidade, @PrecoUnitario);",
                conexao, transacao);
            cmd.Parameters.AddWithValue("@CompraId", compra.Id);
            cmd.Parameters.AddWithValue("@ProdutoId", item.ProdutoId);
            cmd.Parameters.AddWithValue("@Quantidade", item.Quantidade);
            cmd.Parameters.AddWithValue("@PrecoUnitario", item.PrecoUnitario);
            cmd.ExecuteNonQuery();
        }
    }

    private static List<ItemCompra> BuscarItens(int compraId, SqlConnection conexao)
    {
        var itens = new List<ItemCompra>();
        using var cmd = new SqlCommand(@"
SELECT ic.ProdutoId, p.Nome, ic.Quantidade, ic.PrecoUnitario
FROM dbo.ItemCompra ic
INNER JOIN dbo.Produto p ON p.Id = ic.ProdutoId
WHERE ic.CompraId = @CompraId
ORDER BY p.Nome;", conexao);
        cmd.Parameters.AddWithValue("@CompraId", compraId);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
            itens.Add(new ItemCompra
            {
                ProdutoId = reader.GetInt32(0),
                NomeProduto = reader.GetString(1),
                Quantidade = reader.GetInt32(2),
                PrecoUnitario = reader.GetDecimal(3)
            });
        return itens;
    }
}
