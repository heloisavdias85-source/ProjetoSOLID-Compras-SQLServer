using Microsoft.Data.SqlClient;

namespace ProjetoSOLID.dados;

public static class DatabaseInitializer
{
    public static void CriarBancoETabelas(SqlConnectionFactory factory)
    {
        // Cria o banco caso ainda não exista.
        using (var conexaoMaster = new SqlConnection(
            "Server=localhost\\SQLEXPRESS;Database=master;Integrated Security=True;TrustServerCertificate=True;"))
        {
            conexaoMaster.Open();
            using var comandoBanco = conexaoMaster.CreateCommand();
            comandoBanco.CommandText = @"
IF DB_ID(N'ProjetoSOLID') IS NULL
BEGIN
    CREATE DATABASE ProjetoSOLID;
END";
            comandoBanco.ExecuteNonQuery();
        }

        using var conexao = factory.CriarConexao();
        conexao.Open();

        using var comando = conexao.CreateCommand();
        comando.CommandText = @"
IF OBJECT_ID(N'dbo.Produto', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Produto (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Nome NVARCHAR(120) NOT NULL,
        Preco DECIMAL(10,2) NOT NULL CHECK (Preco >= 0),
        Descricao NVARCHAR(500) NOT NULL
    );
END;

IF OBJECT_ID(N'dbo.Compra', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Compra (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Data DATETIME2 NOT NULL
    );
END;

IF OBJECT_ID(N'dbo.ItemCompra', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ItemCompra (
        CompraId INT NOT NULL,
        ProdutoId INT NOT NULL,
        Quantidade INT NOT NULL CHECK (Quantidade > 0),
        PrecoUnitario DECIMAL(10,2) NOT NULL CHECK (PrecoUnitario >= 0),
        CONSTRAINT PK_ItemCompra PRIMARY KEY (CompraId, ProdutoId),
        CONSTRAINT FK_ItemCompra_Compra FOREIGN KEY (CompraId) REFERENCES dbo.Compra(Id) ON DELETE CASCADE,
        CONSTRAINT FK_ItemCompra_Produto FOREIGN KEY (ProdutoId) REFERENCES dbo.Produto(Id)
    );
END;

IF NOT EXISTS (SELECT 1 FROM dbo.Produto WHERE Nome = N'Processador AMD Ryzen 5 5600G')
    INSERT INTO dbo.Produto (Nome, Preco, Descricao) VALUES (N'Processador AMD Ryzen 5 5600G', 899.90, N'Processador de 6 núcleos para computadores de uso geral e jogos.');

IF NOT EXISTS (SELECT 1 FROM dbo.Produto WHERE Nome = N'Placa-mãe ASUS Prime B550M-A')
    INSERT INTO dbo.Produto (Nome, Preco, Descricao) VALUES (N'Placa-mãe ASUS Prime B550M-A', 749.90, N'Placa-mãe AM4 com suporte para memória DDR4.');

IF NOT EXISTS (SELECT 1 FROM dbo.Produto WHERE Nome = N'Memória RAM Kingston Fury 16GB DDR4')
    INSERT INTO dbo.Produto (Nome, Preco, Descricao) VALUES (N'Memória RAM Kingston Fury 16GB DDR4', 329.90, N'Módulo de memória DDR4 de 16 GB para computadores e jogos.');

IF NOT EXISTS (SELECT 1 FROM dbo.Produto WHERE Nome = N'SSD Kingston NV2 1TB')
    INSERT INTO dbo.Produto (Nome, Preco, Descricao) VALUES (N'SSD Kingston NV2 1TB', 459.90, N'Armazenamento SSD NVMe de 1 TB.');

IF NOT EXISTS (SELECT 1 FROM dbo.Produto WHERE Nome = N'Placa de vídeo NVIDIA GeForce RTX 4060')
    INSERT INTO dbo.Produto (Nome, Preco, Descricao) VALUES (N'Placa de vídeo NVIDIA GeForce RTX 4060', 1899.90, N'Placa de vídeo para jogos em alta definição.');

IF NOT EXISTS (SELECT 1 FROM dbo.Produto WHERE Nome = N'Fonte Corsair CV550 550W')
    INSERT INTO dbo.Produto (Nome, Preco, Descricao) VALUES (N'Fonte Corsair CV550 550W', 349.90, N'Fonte de alimentação de 550 W com certificação 80 Plus Bronze.');";
        comando.ExecuteNonQuery();
    }
}
