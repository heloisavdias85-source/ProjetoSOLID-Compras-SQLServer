using ProjetoSOLID.model;
namespace ProjetoSOLID.view;
public class CompraView : ICompraView
{
    public void MostrarCompra(Compra c)
    {
        Console.WriteLine($"\nCompra #{c.Id} | Data: {c.Data:dd/MM/yyyy HH:mm} | Total: {c.Total:C}");
        foreach (var item in c.Itens)
            Console.WriteLine($"  - Produto ID: {item.ProdutoId} | {item.NomeProduto} | Qtd.: {item.Quantidade} | Unitário: {item.PrecoUnitario:C} | Subtotal: {(item.Quantidade * item.PrecoUnitario):C}");
    }
    public void MostrarCompras(List<Compra> compras)
    {
        if (compras.Count == 0) { Console.WriteLine("Nenhuma compra cadastrada."); return; }
        foreach (var compra in compras) MostrarCompra(compra);
    }
}
