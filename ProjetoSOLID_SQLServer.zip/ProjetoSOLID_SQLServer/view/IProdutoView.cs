using ProjetoSOLID.model;
namespace ProjetoSOLID.view;
public interface IProdutoView { void MostrarProduto(Produto produto); void MostrarProdutos(List<Produto> produtos); }
