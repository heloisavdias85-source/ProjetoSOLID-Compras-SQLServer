using ProjetoSOLID.model;
namespace ProjetoSOLID.view;
public interface ICompraView { void MostrarCompra(Compra compra); void MostrarCompras(List<Compra> compras); }
