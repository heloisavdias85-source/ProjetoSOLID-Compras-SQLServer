using ProjetoSOLID.model;
using ProjetoSOLID.dados;
namespace ProjetoSOLID.view;
public class CadastroCompra : ICadastroView<Compra>
{
    private readonly IRepository<Produto> _produtos;
    public CadastroCompra(IRepository<Produto> produtos) => _produtos = produtos;

    public Compra ObterDados()
    {
        var produtos = _produtos.ListarTodos();
        if (produtos.Count == 0) throw new InvalidOperationException("Cadastre pelo menos um produto antes de registrar uma compra.");
        Console.WriteLine("Produtos disponíveis:");
        foreach (var p in produtos) Console.WriteLine($"{p.Id} - {p.Nome} ({p.Preco:C})");

        var compra = new Compra { Data = DateTime.Now };
        while (true)
        {
            Console.Write("\nID do produto (0 para concluir a compra): ");
            if (!int.TryParse(Console.ReadLine(), out int id)) { Console.WriteLine("ID inválido."); continue; }
            if (id == 0)
            {
                if (compra.Itens.Count == 0)
                {
                    Console.WriteLine("Adicione pelo menos um produto antes de concluir.");
                    continue;
                }

                Console.WriteLine($"Total da compra: {compra.Total:C}");
                Console.Write("Concluir compra? (S/N): ");
                if (string.Equals(Console.ReadLine(), "S", StringComparison.OrdinalIgnoreCase)) break;

                Console.WriteLine("Compra não concluída. Continue adicionando produtos.");
                continue;
            }
            var produto = _produtos.BuscarPorId(id);
            if (produto is null) { Console.WriteLine("Produto não encontrado."); continue; }
            Console.Write("Quantidade: ");
            if (!int.TryParse(Console.ReadLine(), out int qtd) || qtd <= 0) { Console.WriteLine("Quantidade inválida."); continue; }
            var existente = compra.Itens.FirstOrDefault(i => i.ProdutoId == id);
            if (existente is null)
                compra.Itens.Add(new ItemCompra { ProdutoId = id, NomeProduto = produto.Nome, Quantidade = qtd, PrecoUnitario = produto.Preco });
            else existente.Quantidade += qtd;
        }
        if (compra.Itens.Count == 0) throw new InvalidOperationException("A compra precisa ter pelo menos um produto.");
        return compra;
    }
    public void ExibirMensagem(string mensagem) => Console.WriteLine(mensagem);
}
