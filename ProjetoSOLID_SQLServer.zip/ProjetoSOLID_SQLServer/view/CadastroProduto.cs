using ProjetoSOLID.model;
using System.Globalization;
namespace ProjetoSOLID.view;
public class CadastroProduto : ICadastroView<Produto>
{
    public Produto ObterDados()
    {
        Console.Write("Nome: ");
        string nome = Console.ReadLine() ?? "";
        Console.Write("Preço: ");
        decimal preco = LerDecimal();
        Console.Write("Descrição: ");
        string descricao = Console.ReadLine() ?? "";
        return new Produto(0, nome, preco, descricao);
    }
    public void ExibirMensagem(string mensagem) => Console.WriteLine(mensagem);
    private static decimal LerDecimal()
    {
        decimal preco = 0m;
             Console.Write("Preço inválido. Digite novamente: ");
        return preco;
    }
}
