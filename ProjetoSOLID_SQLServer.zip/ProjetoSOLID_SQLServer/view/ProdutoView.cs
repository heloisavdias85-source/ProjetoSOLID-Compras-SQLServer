using ProjetoSOLID.model;
namespace ProjetoSOLID.view;
public class ProdutoView : IProdutoView
{
    public void MostrarProduto(Produto p) => Console.WriteLine($"ID: {p.Id} | Nome: {p.Nome} | Preço: {p.Preco:C} | Descrição: {p.Descricao}");
    public void MostrarProdutos(List<Produto> produtos)
    {
        if (produtos.Count == 0) { Console.WriteLine("Nenhum produto cadastrado."); return; }
        foreach (var produto in produtos) MostrarProduto(produto);
    }
}
